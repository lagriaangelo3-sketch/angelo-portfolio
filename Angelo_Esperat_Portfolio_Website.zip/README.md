# Angelo Esperat Portfolio

A responsive one-page portfolio website based on Angelo Esperat's resume.

## Run locally
Open `index.html` in any modern web browser.

## Publish
Upload `index.html` to a static hosting service such as GitHub Pages, Netlify, or Vercel.

## Customize
- Replace the `AE` circle with a professional photo if desired.
- Add LinkedIn/social links in the Contact section.
- Add portfolio projects when available.
